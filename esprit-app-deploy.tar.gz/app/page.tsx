import { HomePage } from "@/presentation/pages/HomePage"

export default function Page() {
  return <HomePage />
} 