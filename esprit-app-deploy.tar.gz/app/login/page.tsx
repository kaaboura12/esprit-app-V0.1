import { LoginPage } from "@/presentation/pages/LoginPage"

export default function Page() {
  return <LoginPage />
} 